﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace SistemCarwash.Model.Entity
{
    public class jenisKendaraan
    {
        public int Id_JenisKendaraan{ get; set; }
        public string Nama_JenisKendaraan{ get; set; }
    }
}
