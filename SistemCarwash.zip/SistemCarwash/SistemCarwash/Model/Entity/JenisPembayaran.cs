﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace SistemCarwash.Model.Entity
{
    public class JenisPembayaran
    {
        public string id_jenisPembayaran { get; set; }
        public string jenisPembayaran { get; set; }
    }
}
