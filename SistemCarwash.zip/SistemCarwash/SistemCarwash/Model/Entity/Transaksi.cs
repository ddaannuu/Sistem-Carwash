﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace SistemCarwash.Model.Entity
{
    public class Transaksi
    {
        public string id_transaksi {  get; set; }   
        public string plat_Nomor {  get; set; }
        public string id_karyawan {  get; set; }
        public string id_pelanggan {  get; set; }   
        public string tanggal {  get; set; }
        public string id_jenisPembayaran {  get; set; } 
        public int total {  get; set; }
        public int harga { get; set; }
    }
}
