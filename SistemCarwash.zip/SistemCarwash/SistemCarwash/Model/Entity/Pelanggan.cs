﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Security.Policy;
using System.Text;
using System.Threading.Tasks;

namespace SistemCarwash.Model.Entity
{
    public class Pelanggan
    {
        public string id_pelanggan { get; set; }    
        public string nama_pelanggan { get; set; }
        public string id_transaksi {  get; set; }   
        public string plat_Nomor {  get; set; }
        public int total {  get; set; }
    }
}
