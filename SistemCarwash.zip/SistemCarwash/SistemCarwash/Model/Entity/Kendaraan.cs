﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace SistemCarwash.Model.Entity
{
    public class Kendaraan
    {
        public string plat_Nomor { get; set; }
        public string id_jenisKendaraan {  get; set; }
        public string warna_kendaraan {  get; set; }
        public int harga {  get; set; }
    }
}
