﻿
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace SistemCarwash.Model.Entity
{
    public class Karyawan
    {
        public string id_karyawan { get; set; }
        public string email {  get; set; }
        public string nama { get; set; }
        public string password {  get; set; }
    }
}
