﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Data.SQLite;
using SistemCarwash.Model.Entity;
using SistemCarwash.Model.Context;


namespace SistemCarwash.Model.Repository
{
    internal class TransaksiRepository
    {
        private SQLiteConnection _conn;

        public TransaksiRepository(DbContext context)
        {
            _conn = context.Conn;
        }

        public int Create(Transaksi tr)
        {
            int result = 0;
            // deklarasi perintah SQL 
            string sql = @"insert into Transaksi ( id_transaksi, plat_Nomor, id_karyawan, tanggal, id_jenisPembayaran, total, harga) values (@idtran,@platno,@idkar,@tanggal,@idjenpem,@total,@harga)";
            // membuat objek command menggunakan blok using 
            using (SQLiteCommand cmd = new SQLiteCommand(sql, _conn))
            {
                // mendaftarkan parameter dan mengeset nilainya 
                cmd.Parameters.AddWithValue("@idtran", tr.id_transaksi);
                cmd.Parameters.AddWithValue("@platno", tr.plat_Nomor);
                cmd.Parameters.AddWithValue("@idkar",tr.id_karyawan);
                cmd.Parameters.AddWithValue("@tanggal", tr.tanggal);
                cmd.Parameters.AddWithValue("@idjenpem", tr.id_jenisPembayaran);
                cmd.Parameters.AddWithValue("@total", tr.total);
                cmd.Parameters.AddWithValue("@harga", tr.harga);


                try
                {
                    result = cmd.ExecuteNonQuery();
                }
                catch (Exception ex)
                {
                    System.Diagnostics.Debug.Print("Create error: {0}", ex.Message);
                }
                // jalankan perintah INSERT dan tampung hasilnya ke dalam variabel result

            }
            return result;

        }
    }
}
