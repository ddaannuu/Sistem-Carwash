﻿using SistemCarwash.Model.Context;
using SistemCarwash.Model.Entity;
using System;
using System.Collections.Generic;
using System.Data.SQLite;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace SistemCarwash.Model.Repository
{
    public class KendaraanRepository
    {
        private SQLiteConnection _conn;

        public KendaraanRepository(DbContext context)
        {
            _conn = context.Conn;
        }

        public int Create(Kendaraan kd)
        {
            int result = 0;
            // deklarasi perintah SQL 
            string sql = @"insert into Kendaraan ( plat_Nomor, id_JenisKendaraan, warna_kendaraan, harga) values (@platno, @idjenken, @waken, @harga)";
            // membuat objek command menggunakan blok using 
            using (SQLiteCommand cmd = new SQLiteCommand(sql, _conn))
            {
                // mendaftarkan parameter dan mengeset nilainya 
                cmd.Parameters.AddWithValue("@platno", kd.plat_Nomor);
                cmd.Parameters.AddWithValue("@idjenken", kd.id_jenisKendaraan);
                cmd.Parameters.AddWithValue("@waken", kd.warna_kendaraan);
                cmd.Parameters.AddWithValue("@harga", kd.harga);

                try
                {
                    result = cmd.ExecuteNonQuery();
                }
                catch (Exception ex)
                {
                    System.Diagnostics.Debug.Print("Create error: {0}", ex.Message);
                }
                // jalankan perintah INSERT dan tampung hasilnya ke dalam variabel result

            }
            return result;

        }
        public int Update(Kendaraan kd)
        {
            int result = 0;

            // deklarasi perintah SQL
            string sql = @"update mahasiswa set  = id_jenisKendaraan = @idjenken, warna_kendaraan = @waken, harga = @harga
                           where plat_Nomor = @platno";

            // membuat objek command menggunakan blok using
            using (SQLiteCommand cmd = new SQLiteCommand(sql, _conn))
            {
                // mendaftarkan parameter dan mengeset nilainya
                cmd.Parameters.AddWithValue("@platno", kd.plat_Nomor);
                cmd.Parameters.AddWithValue("@idjenken", kd.id_jenisKendaraan);
                cmd.Parameters.AddWithValue("@waken", kd.warna_kendaraan);
                cmd.Parameters.AddWithValue("@harga", kd.harga);

                try
                {
                    // jalankan perintah UPDATE dan tampung hasilnya ke dalam variabel result
                    result = cmd.ExecuteNonQuery();
                }
                catch (Exception ex)
                {
                    System.Diagnostics.Debug.Print("Update error: {0}", ex.Message);
                }
            }

            return result;
        }
        public int Delete(Kendaraan kd)
        {
            int result = 0;

            // deklarasi perintah SQL
            string sql = @"delete from mahasiswa
                           where plat_Nomor = @platno";

            // membuat objek command menggunakan blok using
            using (SQLiteCommand cmd = new SQLiteCommand(sql, _conn))
            {
                // mendaftarkan parameter dan mengeset nilainya
                cmd.Parameters.AddWithValue("@platno", kd.plat_Nomor);

                try
                {
                    // jalankan perintah DELETE dan tampung hasilnya ke dalam variabel result
                    result = cmd.ExecuteNonQuery();
                }
                catch (Exception ex)
                {
                    System.Diagnostics.Debug.Print("Delete error: {0}", ex.Message);
                }
            }

            return result;
        }
    }
}
