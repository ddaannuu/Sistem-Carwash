﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Data.SQLite;
using SistemCarwash.Model.Entity;
using SistemCarwash.Model.Context;


namespace SistemCarwash.Model.Repository
{
    public class PelangganRepository
    {
        private SQLiteConnection _conn;

        public PelangganRepository(DbContext context)
        {
            _conn = context.Conn;
        }

        public int Create(Pelanggan pg)
        {
            int result = 0;
            // deklarasi perintah SQL 
            string sql = @"insert into Pelanggan ( id_pelanggan, nama_pelanggan, id_transaksi, plat_Nomor, total) values (@idpl, @namapl, @idtran, @platno, @total)";
            // membuat objek command menggunakan blok using 
            using (SQLiteCommand cmd = new SQLiteCommand(sql, _conn))
            {
                // mendaftarkan parameter dan mengeset nilainya 
                cmd.Parameters.AddWithValue("@idpl", pg.id_pelanggan);
                cmd.Parameters.AddWithValue("@namapl", pg.nama_pelanggan);
                cmd.Parameters.AddWithValue("@idtran", pg.id_transaksi);
                cmd.Parameters.AddWithValue("@platno", pg.plat_Nomor);
                cmd.Parameters.AddWithValue("@total", pg.total);


                try
                {
                    result = cmd.ExecuteNonQuery();
                }
                catch (Exception ex)
                {
                    System.Diagnostics.Debug.Print("Create error: {0}", ex.Message);
                }
                // jalankan perintah INSERT dan tampung hasilnya ke dalam variabel result

            }
            return result;

        }
        public int Update(Pelanggan pg)
        {
            int result = 0;

            // deklarasi perintah SQL
            string sql = @"update mahasiswa set  = nama_pelanggan = @namapl, id_transaksi = @idtran, plat_Nomor = @platno, total = @total
                           where id_pelangga = @idpl";

            // membuat objek command menggunakan blok using
            using (SQLiteCommand cmd = new SQLiteCommand(sql, _conn))
            {
                // mendaftarkan parameter dan mengeset nilainya
                cmd.Parameters.AddWithValue("@idpl", pg.id_pelanggan);
                cmd.Parameters.AddWithValue("@namapl", pg.nama_pelanggan);
                cmd.Parameters.AddWithValue("@idtran", pg.id_pelanggan);
                cmd.Parameters.AddWithValue("@platno", pg.plat_Nomor);
                cmd.Parameters.AddWithValue("@total", pg.total);

                try
                {
                    // jalankan perintah UPDATE dan tampung hasilnya ke dalam variabel result
                    result = cmd.ExecuteNonQuery();
                }
                catch (Exception ex)
                {
                    System.Diagnostics.Debug.Print("Update error: {0}", ex.Message);
                }
            }

            return result;
        }
        public int Delete(Pelanggan pg)
        {
            int result = 0;

            // deklarasi perintah SQL
            string sql = @"delete from mahasiswa
                           where id_pelanggan = @idpl";

            // membuat objek command menggunakan blok using
            using (SQLiteCommand cmd = new SQLiteCommand(sql, _conn))
            {
                // mendaftarkan parameter dan mengeset nilainya
                cmd.Parameters.AddWithValue("@idpl", pg.id_pelanggan);

                try
                {
                    // jalankan perintah DELETE dan tampung hasilnya ke dalam variabel result
                    result = cmd.ExecuteNonQuery();
                }
                catch (Exception ex)
                {
                    System.Diagnostics.Debug.Print("Delete error: {0}", ex.Message);
                }
            }

            return result;
        }

    }
}
