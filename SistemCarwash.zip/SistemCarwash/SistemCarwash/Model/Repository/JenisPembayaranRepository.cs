﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Data.SQLite;
using SistemCarwash.Model.Entity;
using SistemCarwash.Model.Context;

namespace SistemCarwash.Model.Repository
{
    public class JenisPembayaranRepository
    {
        private SQLiteConnection _conn;

        public JenisPembayaranRepository(DbContext context)
        {
            _conn = context.Conn;
        }

        public int Create(JenisPembayaran jenpem)
        {
            int result = 0;
            // deklarasi perintah SQL 
            string sql = @"insert into jenisKendaraan ( id_jenisPembayaran, jenisPembayaran) values (@idjenpem, @namajp)";
            // membuat objek command menggunakan blok using 
            using (SQLiteCommand cmd = new SQLiteCommand(sql, _conn))
            {
                // mendaftarkan parameter dan mengeset nilainya 
                cmd.Parameters.AddWithValue("@idjenpem", jenpem.id_jenisPembayaran);
                cmd.Parameters.AddWithValue("@namajp", jenpem.jenisPembayaran);

                try
                {
                    result = cmd.ExecuteNonQuery();
                }
                catch (Exception ex)
                {
                    System.Diagnostics.Debug.Print("Create error: {0}", ex.Message);
                }
                // jalankan perintah INSERT dan tampung hasilnya ke dalam variabel result

            }
            return result;

        }
        public int Update(JenisPembayaran jenpem)
        {
            int result = 0;

            // deklarasi perintah SQL
            string sql = @"update mahasiswa set  = jenisPembayaran = @namajp
                           where id_jenisPembayaran = @idjenpem";

            // membuat objek command menggunakan blok using
            using (SQLiteCommand cmd = new SQLiteCommand(sql, _conn))
            {
                // mendaftarkan parameter dan mengeset nilainya
                cmd.Parameters.AddWithValue("@idjenpem", jenpem.id_jenisPembayaran);
                cmd.Parameters.AddWithValue("@namapl", jenpem.jenisPembayaran);

                try
                {
                    // jalankan perintah UPDATE dan tampung hasilnya ke dalam variabel result
                    result = cmd.ExecuteNonQuery();
                }
                catch (Exception ex)
                {
                    System.Diagnostics.Debug.Print("Update error: {0}", ex.Message);
                }
            }

            return result;
        }
        public int Delete(JenisPembayaran jenpem)
        {
            int result = 0;

            // deklarasi perintah SQL
            string sql = @"delete from JenisPembayaran
                           where id_jenisPembayaran = @idjenpem";

            // membuat objek command menggunakan blok using
            using (SQLiteCommand cmd = new SQLiteCommand(sql, _conn))
            {
                // mendaftarkan parameter dan mengeset nilainya
                cmd.Parameters.AddWithValue("@idjenpem", jenpem.id_jenisPembayaran);

                try
                {
                    // jalankan perintah DELETE dan tampung hasilnya ke dalam variabel result
                    result = cmd.ExecuteNonQuery();
                }
                catch (Exception ex)
                {
                    System.Diagnostics.Debug.Print("Delete error: {0}", ex.Message);
                }
            }

            return result;
        }
    }
}
